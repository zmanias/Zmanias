# metainstall
Proses penginstallan metasploit....
Usahakan kuota kamu lebih dari 1Gb
Dan penyimpanan kamu lebih dari 1Gb
Biar saat sedang install metasploit tidak ada yang error
Cek versi android kamu
Saat meng install metasploit ntar ada pilihan
1. Versi 5+
2. Versi 7+
Usahakan dengan benar versi os anda
