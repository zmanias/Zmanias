#!/bin/sh
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'

clear
sleep 1
echo $white"╔══════════════════════════════════╗"
echo $white"║"$purple"         DDOS Active"$white"["$green"√"$white"]           ║"
echo "╠══════════════════════════════════╝"
sleep 1
read -p '║ Masukan IP ~> ' ip
read -p "║ Masukan Port ~> " port
read -p "║ Masukan Kecepatan Attack ~> " turbo
echo "║"
echo '╚═════════════════════════════════╝'
sleep 1
clear
echo $white"╔══════════════════════════════════╗"
echo $white'║   Menyerang Situs Dengan DDOS    ║'
echo $white"╠══════════════════════════════════╝"
echo $white'║ Alamat IP :' $ip
echo $white'║ Port :' $port
echo $white'║ Kecepatan menyerang :' $turbo
echo $white'║'
echo $white'╚══[ Sedang Di Proses ]════════════╝'
echo $white'Tunggu Sampai Down'
sleep 2
echo $white"╔══════════════════════════════════╗"
echo '║'$green' Hijau'$white 'Sedang Memulai'
echo $white'║'$blue' Biru'$white 'Hampir Down'
echo $white'║'$red' Merah'$white 'Berhasil Down'
echo $white'╚═════════════════════════════════╝'
sleep 3
python3 ddos.py -s$ip -p$port -t$turbo
