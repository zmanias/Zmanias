# spam telfon dan sms auto
Cara install
pkg update && pkg upgrade
pkg install bash
pkg install git
git clone https://github.com/crack-org/spam
cd spam
sh install.sh
bash spam.sh
