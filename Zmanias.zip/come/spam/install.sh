echo "Sedang meng install bahan..."
echo " "
pkg update && pkg upgrade
pkg install figlet
pkg install python && pkg install python2
pip2 install request
pkg install php
echo "Install bahan selesai..."
